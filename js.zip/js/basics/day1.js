console.log("Hello, Precious");
console.log("Are your horny?");

// a = 12;

// b = 34;
// c = a + b;
// console.log(c);

radius = 10;

pie = 3.142;
area = pie * radius ** 2;
console.log(area);

b = 16;
a = 10;
c = 12;
d = b ** 2 - 4 * a * c;
console.log(d);
