// b = 16;
// a = 10;
// c = 12;
// d = b ** 2 - 4 * a * c;
// console.log(d);

// let b = 16;
// var a = 10;
// const c = 12;
// let d = b ** 2 - 4 * a * c;
// console.log(d);

let age = 20;

year_of_birth = 2022 - age;
console.log(year_of_birth);
